-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Aug 20, 2024 at 03:16 PM
-- Server version: 8.0.39
-- PHP Version: 7.4.3-4ubuntu2.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `own_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `mobile_id` int DEFAULT NULL,
  `quantity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mobiles`
--

CREATE TABLE `mobiles` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `rating` float(3,1) NOT NULL,
  `photo` blob NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `mobiles`
--

INSERT INTO `mobiles` (`id`, `name`, `price`, `rating`, `photo`, `created_at`, `updated_at`) VALUES
(1, 'vivo T2x 5G (Aurora Gold, 128 GB) (4 GB RAM)', 11999.00, 4.4, 0x7669766f7432782e6a706567, '2024-08-19 05:12:00', '2024-08-20 09:15:00'),
(2, 'Apple iPhone 14 (Starlight, 128 GB)', 57999.00, 4.6, 0x6970686f6e6531342e6a706567, '2024-08-19 05:12:00', NULL),
(3, 'Google Pixel 7 (Snow, 128 GB) (8 GB RAM)', 32999.00, 4.3, 0x506978656c372e6a706567, '2024-08-19 05:12:00', NULL),
(4, 'realme 11x 5G (Purple Dawn, 128 GB) (6 GB RAM)', 14999.00, 4.4, 0x7265616c6d653131782e6a706567, '2024-08-19 05:12:00', NULL),
(5, 'SAMSUNG Galaxy F14 5G (B.A.E. Purple, 128 GB) (4 GB RAM)', 10990.00, 4.2, 0x47616c6178794631342e6a706567, '2024-08-19 05:12:00', NULL),
(6, 'Apple iPhone 13 (Green, 128 GB)', 50990.00, 4.6, 0x6950686f6e6531332e6a706567, '2024-08-19 05:12:00', NULL),
(7, 'SAMSUNG Galaxy S23 5G (Lavender, 256 GB) (8 GB RAM)', 49999.00, 4.5, 0x47616c617879533233732e6a706567, '2024-08-19 05:12:00', NULL),
(8, 'OPPO Reno8T 5G (Sunrise Gold, 128 GB) (8 GB RAM)', 38999.00, 4.3, 0x52656e6f38542e6a706567, '2024-08-19 05:12:00', NULL),
(9, 'POCO M4 5G (Cool Blue, 64 GB) (4 GB RAM)', 12999.00, 4.2, 0x504f434f4d342e6a706567, '2024-08-19 05:12:00', NULL),
(10, 'vivo X90 (Asteroid Black, 256 GB) (8 GB RAM)', 61999.00, 4.4, 0x7669766f5839302e6a706567, '2024-08-19 05:12:00', NULL),
(11, 'Motorola Edge 30 Fusion (Cosmic grey, 128 GB) (8 GB RAM)', 42999.00, 4.3, 0x4564676533302e6a706567, '2024-08-19 05:12:00', NULL),
(12, 'Apple iPhone 15 (Black, 128 GB)', 65499.00, 4.6, 0x6950686f6e6531352e6a706567, '2024-08-19 05:12:00', NULL),
(13, 'SAMSUNG Galaxy M14 4G (Arctic Blue, 64 GB) (4 GB RAM)', 8569.00, 4.0, 0x47616c6178794d31342e6a706567, '2024-08-19 05:12:00', '2024-08-19 12:16:30'),
(14, 'Nothing Phone (2a) 5G (Black, 256 GB) (12 GB RAM)', 27999.00, 4.4, 0x50686f6e65283261292e6a706567, '2024-08-19 05:12:00', NULL),
(15, 'Nothing Phone (2a) 5G (Black, 256 GB) (8 GB RAM)', 25999.00, 4.4, 0x50686f6e6528326129382e6a706567, '2024-08-19 05:12:00', NULL),
(16, 'Motorola Edge 50 Pro 5G (Moonlight Pearl, 256 GB) (8 GB RAM)', 29999.00, 4.4, 0x45646765353050726f2e6a706567, '2024-08-19 05:12:00', NULL),
(17, 'realme Narzo 70 Pro 5G (Glass Gold, 256 GB) (8 GB RAM)', 18266.00, 4.4, 0x4e61727a6f373050726f2e6a706567, '2024-08-19 05:12:00', NULL),
(38, 'shukoor12', 100000.00, 1.5, 0x646f636d65312e6a7067, '2024-08-20 08:54:28', '2024-08-20 09:13:12'),
(39, 'Dilamo 15 pro max', 100000.00, 5.0, 0x64696c616d6f2e706e67, '2024-08-20 09:30:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `is_admin`) VALUES
(1, 'Yaseen B Muhammed', 'yaseenbsm@gmail.com', '$2y$10$.HXJH7t5qhg/CzwpI6kEku0BHtZxl66Io2vpb5nAWQriKqEt84Bc2', 1),
(3, 'Yaseen B Muhammed', 'yaseenbsm.work@gmail.com', '$2y$10$9.L/wqnbIVCl/lkOilQnfuGL3kdrSUibKyFqoj0H9lrlIQ3cZScte', 0),
(4, 'Mehdi', 'mehdi@gmail.com', '$2y$10$82pYy9x/jL4tkTRCka0ebeXEsFPIJdZwUkYwuq3KfRMZUPar7V4Oi', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `mobile_id` (`mobile_id`);

--
-- Indexes for table `mobiles`
--
ALTER TABLE `mobiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mobiles`
--
ALTER TABLE `mobiles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`mobile_id`) REFERENCES `mobiles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
